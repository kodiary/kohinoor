-- phpMyAdmin SQL Dump
-- version 4.4.15.8
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 30, 2017 at 01:32 PM
-- Server version: 5.6.31
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kohinoor`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `email`) VALUES
(1, 'admin', 'admin', 'warriorbik@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `created_date` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `description`, `image`, `slug`, `created_date`) VALUES
(2, '5 Must Do Experiences In Nepal', '<p>You simply can&rsquo;t go to Nepal and not <strong>take a scenic Everest Flight</strong>. These flights leave Kathmandu early in the morning and take a scenic route towards the highest mountain in the world. Flights do get postponed and cancelled due to bad weather, so we recommend leaving at least one extra day for this awesome flight before your rafting trip.</p>\r\n\r\n<p><strong>Take a few days at Bardia National Park</strong> in western Nepal for some wonderful wildlife viewing. Take a unique ride on an Asian Elephant through the wonderful jungle for chances to see asian rhinoceros, mugger crocodiles and even the elusive tiger. Conveniently located close the the take out of the Karnali River, a few days spent exploring and relaxing in this gorgeous park, is well worth the extra few days.</p>\r\n\r\n<p><strong>Explore the fascinating city of Kathmandu</strong>. Described by legendary New Zealand river runner, David Allardice, as the world&rsquo;s largest outdoor museum, you can easily spend 2-3 days exploring this fascinating city. A visit to Pashupatinath, Durbar Square and &lsquo;The Monkey Temple&rsquo; are fascinating parts of the city we share with all of our guests. If you are a retail therapist of note, you&rsquo;ll love shopping for Tibetan Art, woollen goods and may trinkets for your friends and family.</p>\r\n\r\n<p><strong>Enjoy a yoga retreat in Nepal</strong>. Step out of your busy routine and into the living Buddhist traditions of Nepal. You can take a few days out after your Sun Kosi rafting trip in one of the many retreats on offer around Kathmandu. There are also a range of meditation centres offering&nbsp;different dimensions of health-physical, sensorial, mental and spiritual.</p>\r\n\r\n<p>Last but certainly not least, <strong>take a river trip in this stunning land</strong>. My true passion for multi day rafting adventures came from running the incredible journeys on offer in Nepal in the 1990&rsquo;s. Each year we return to share these trips with our guests, with all of the trips offering something unique. If you are after a true adventure including a 4 day hike to the river and then running in excess of 140 rapids in 120 kilometres, then the Tamur River, should be your next adventure.</p>\r\n', '418457_738555.jpg', '5-Must-Do-Experiences-In-Nepal', '2016-08-28'),
(3, 'Rafting in Nepal:', '<p>Rafting in Nepal: The Trishuli is Nepal&rsquo;s most popular rafting river, impressive gorges, exciting rapids, some easier sections, and easily accessible from Kathmandu and Pokhara. The Trishuli white water trip exciting, fun and safe for all age groups. Our 2-day trips will overnight at Trishuli River Retreat our private camp with comfortable safari-tented accommodation set in private grounds with river views surrounded by forests. You can expect this to be the most memorable Rafting in Nepal.</p>\r\n\r\n<p>Recommended for intermediate Kayakers. The Trishuli rafting in Nepal can be easily combined with a trek out of Pokhara and/or a visit to Royal Chitwan National Park.</p>\r\n', '637512_709320.jpg', 'Rafting-in-Nepal-', '2016-08-28'),
(4, 'test blog', '<p>asd asdas das asd asdasd asdas dasdasd asd</p>\r\n', '837921_319519.jpg', 'test-blog', '2016-08-29'),
(5, 'New Blog', '<pre>\r\n<code>google.maps.Map.prototype.clearOverlays = function() {\r\n  for (var i = 0; i &lt; markersArray.length; i++ ) {\r\n    markersArray[i].setMap(null);\r\n  }\r\n  markersArray.length = 0;\r\n}</code></pre>\r\n\r\n<p>III. Push markers in the &#39;markerArray&#39; before calling the following:</p>\r\n\r\n<pre>\r\n<code>markersArray.push(marker);\r\ngoogle.maps.event.addListener(marker,&quot;click&quot;,function(){});</code></pre>\r\n\r\n<p>IV. Call the <code>clearOverlays();</code> or <code>map.clearOverlays();</code> function wherever required.</p>\r\n\r\n<p>That&#39;s it!!</p>\r\n\r\n<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<p><a href="http://stackoverflow.com/a/2439176/1188906">share</a><a href="http://stackoverflow.com/posts/2439176/edit">edit</a><a href="http://stackoverflow.com/questions/1544739/google-maps-api-v3-how-to-remove-all-markers#">flag</a></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', '514038_719390.jpg', 'New-Blog', '2016-09-26');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

DROP TABLE IF EXISTS `enquiry`;
CREATE TABLE IF NOT EXISTS `enquiry` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime NOT NULL,
  `type` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`id`, `name`, `email`, `phone`, `message`, `created_at`, `type`, `status`) VALUES
(1, 'Warriors Bay', 'info@trinoweb.com', '', 'asdas sdasdasd', '2016-08-29 07:01:48', 'Contact Enquiry', 1),
(2, 'Kumar', 'warriorbik@gmail.com', '023-540443, 540195', 'i ned this package', '2016-09-26 11:28:38', 'Package Enquiry', 1),
(3, 'BIkash', 'warriorbik@gmail.com', '+9779851195660', 'thius is test', '2016-09-26 11:52:42', 'Contact Enquiry', 1),
(4, 'BIkash', 'warriorbik@gmail.com', '+9779851195660', 'thius is test', '2016-09-26 11:52:50', 'Contact Enquiry', 1),
(5, 'BIkash', 'warriorbik@gmail.com', '+9779851195660', 'asd asdasd asd asdasda sd as', '2016-09-26 12:41:29', 'Package Enquiry', 1),
(6, 'tourist 1', 'warriorbik@gmail.com', '9851195660', 'i woukld lijke to know abpout this package', '2016-11-11 09:32:26', 'Package Enquiry', 1);

-- --------------------------------------------------------

--
-- Table structure for table `iteniery`
--

DROP TABLE IF EXISTS `iteniery`;
CREATE TABLE IF NOT EXISTS `iteniery` (
  `id` int(11) NOT NULL,
  `pid` int(255) NOT NULL,
  `day` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=276 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `iteniery`
--

INSERT INTO `iteniery` (`id`, `pid`, `day`, `description`, `title`) VALUES
(176, 5, '1', 'Kathmandu - Barabise (870 m) (4 hrs bus ride) ', 'Day 1'),
(177, 5, '2', 'Barabise (870 m) - Jalbire (830 m) 8 hrs ', 'Day 2'),
(178, 5, '3', 'Jalbire (830 m) - Khobre (2435 m) 8 hrs ', 'Day 3'),
(179, 5, '4', 'Khobre (2435 m) - Pokhare Banjang (1575 m) 9 hrs ', 'Day 4'),
(180, 5, '5', 'Pokhare Banjang (1574 m) - Gyalthung (985 m) 2 hrs - bus ride to Kathmandu 4 hrs', 'Day 5'),
(181, 4, '1', 'An encounter with the Himalayas in our Ecureuil AS 350 B3e will be a life changing experience. In addition, we offer an opportunity to get a close panoramic view of the Himalayas at your own pace and comfort. Book a mountain flight with us to enjoy the beauty of Nepal in a luxurious way at attractive rates. ', 'Few Hours'),
(182, 6, '1', 'The standard paragliding flight takes off from Sarangkot (30 min. by jeep from Pokhara), floats above Sarangkot for a while, then heads over Pokhara before performing spiralling acrobatics (optional) on descent to Phewa Tal next to Lakeside.', '30mins - 1hr'),
(183, 8, '1', 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don''t look even slightly believable.', '1 day'),
(184, 3, '1', 'Seated high on the back of a trained elephant exploring the grasslands and core area of the park, you become an intergral part of the life of the Chitwan National Park. The elephant safari, though not the most comfortable rides, is an amazing experience. And it doesn’t take long to spot at least a rhino in these forests. The ride will be enjoyed of 2 hrs. The time can be chosen from 10:00AM to 4:00PM.', '1 Day safari'),
(240, 2, '1', 'Flight Kathmandu - Pokhara - drive to Nayapul (1 1/2 hrs) - trek to Ulleri (1940 m) 6 hrs', 'Ktm - Pok - Nayapul'),
(241, 2, '2', 'Ulleri (1940 m) - Ghorepani (2750 m) 5 hrs ', 'Begin your Trek'),
(242, 2, '3', 'Ghorepani (2750 m) - Poon Hill (3194 m). Get an early start to watch the sunrise over the Annapurnas from Poon Hill, then on to Tadapani (2590 m) 6 hrs', 'Start Climbing'),
(243, 2, '4', 'Tadapani (2590 m) - Chomrong (2210 m) 4 hrs ', 'Start Struggling'),
(244, 2, '5', 'Chomrong (2210 m) - Himalayan Hotel (2840 m) 7 hrs', 'Feel the Chill'),
(245, 2, '6', 'Himalayan Hotel (2840 m) - Machapuchare Base Camp (3700 m) 4 hrs', 'Experience the Altitude'),
(246, 2, '7', 'Machapuchare Base Camp (3700 m) - Annapurna Base Camp (4130 m) 3 hrs (1/2 day hike to glacier optional)', 'Forget your struggle with the beauty'),
(247, 2, '8', 'Annapurna Base Camp (4130 m) - Bamboo (2310 m) 7 hrs', 'Say Good Bye to the Base Camp'),
(248, 2, '9', 'Bamboo (2310 m) - Jhinu Danda (1780 m); visit hotsprings', 'Realize getting downhill is harder'),
(249, 2, '10', 'Jhinu Danda (1780 m) - Ghandruk (5 hrs)', 'Getting closer'),
(250, 2, '11', 'Ghandruk - Nayapul (5 hrs) and by bus/taxi to Pokhara (1 1/2 hrs)', 'Crave to see the road'),
(252, 1, '1', 'Begins with the early morning breakfast at 6:00 AM followed by bus trip from Kathmandu to Bigfig resort, Dhading. With a short rest the team gets ready with their rafting costumes and safety jacket. We let the team to get friendly with water and the rafting boat for some time and begin the thrill at 10:00 AM. Fighting with tides goes on for next 2 hrs and we end up at Narayanghat at 12:00PM noon. Lunch shall served at 1:00 PM at Narayani River side Restaurant. After short break for snap shots we get back to bus at 3:00PM. An hour of tea break will be enjoyed on the way to kathmandu at Naubise. Finally, we reach Kathmandu at 8:00PM.', '1 day'),
(253, 10, '1', 'asda sdasd', 'test'),
(254, 10, '2', 'asdasd', 'asdasd'),
(255, 10, '3', 'asdasd', 'asdasd'),
(256, 10, '4', 'dfgdfgdf', 'dfgdfg'),
(257, 10, '5', 'fghfghfg', 'fghfhfgh'),
(258, 10, '6', 'hjkhjkhj', 'werws'),
(259, 7, '1', 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don''t look even slightly believable.', 'asd sdasd'),
(260, 7, '2', 'asd asdasd asd', 'asd asdgsdfsdfsd'),
(261, 7, '3', 'sadas sdas das', 'fghfghfg'),
(265, 9, '1', 'asdas sdasd', 'dfghaasd asdas'),
(266, 9, '2', 'fghfghfg', 'fghfghf'),
(267, 9, '3', 'asdasd', 'gfhfgh'),
(272, 12, '1', 'asdasdasdas', 'asdasd'),
(273, 11, '1', 'asd asd gasda asdasd asd', 'gorepani asd asd'),
(274, 11, '2', 'asdas', 'gasd asdas'),
(275, 11, '3', 'asdasd asdasd', 'gsdfsd asdas');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
CREATE TABLE IF NOT EXISTS `members` (
  `id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `image`, `link`) VALUES
(1, '133911_910552.jpg', 'http://www.kodiary.com'),
(3, '548889_424407.jpg', ''),
(4, '215332_597930.jpg', ''),
(5, '35583_786590.jpg', ''),
(7, '715637_224945.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
CREATE TABLE IF NOT EXISTS `packages` (
  `id` int(11) NOT NULL,
  `cat_id` int(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `added_on` date DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `grade` varchar(255) DEFAULT NULL,
  `days` int(11) NOT NULL,
  `start_point` varchar(255) DEFAULT NULL,
  `end_point` varchar(255) DEFAULT NULL,
  `route_map` varchar(255) DEFAULT NULL,
  `best_time` varchar(255) DEFAULT NULL,
  `cost_detail` text,
  `country_id` int(11) DEFAULT NULL,
  `is_new` int(11) NOT NULL,
  `is_tour` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `cat_id`, `title`, `image`, `description`, `added_on`, `slug`, `grade`, `days`, `start_point`, `end_point`, `route_map`, `best_time`, `cost_detail`, `country_id`, `is_new`, `is_tour`) VALUES
(1, 1, 'Trishuli Rafting from Big-fig', 'img588_2016_07_21_10_14_57.jpg', '<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n', NULL, 'Trishuli-Rafting-from-Big-fig', 'Easy', 1, '', '', NULL, '', '', 146, 0, 0),
(2, 2, 'Annapurna Base Camp - Trek', 'img63_2016_07_21_10_35_12.JPG', '<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n', NULL, 'Annapurna-Base-Camp---Trek', 'Easy', 0, 'Nayapul', 'Nayapul', '195770_856323.jpg', 'March-April and September-November', '<p><strong>Cost Includes</strong></p>\r\n\r\n<ul>\r\n	<li>All Airports pick up and drop.</li>\r\n	<li>3 nights&nbsp; standard hotel in Kathmandu with breakfast.</li>\r\n	<li>2 nights your standard hotel in Pokhara with BB.</li>\r\n	<li>Accommodation tea-houses in mountain during the trek</li>\r\n	<li>All 3 meals per day during the trek [B+L+D]</li>\r\n	<li>Tourist standard bus between Kathmandu / Pokhara / Kathmandu</li>\r\n	<li>An experienced English-speaking trekking guide, assistant trek guide as per bigger size of group of trekkers: (2 trekkers:1 porter) including their salary, insurance, equipment, food and lodging</li>\r\n	<li>Down jacket, sleeping bag, duffel bag, and trekking map (down jacket and sleeping bag are to be returned after trip completion)</li>\r\n	<li>All necessary paper work and permits (ACAP, TIMS )</li>\r\n	<li>A medical supplies (first aid kit will be available)</li>\r\n	<li>All government and local taxes</li>\r\n</ul>\r\n\r\n<p><strong>Cost excludes:</strong></p>\r\n\r\n<ul>\r\n	<li>Nepal Visa fee (Nepal provides on arrival visa in Immigration, bring accurate USD cash and two passport photographs,)</li>\r\n	<li>International airfare to and from Kathmandu</li>\r\n	<li>Meal city like Kathmandu and Pokhara.</li>\r\n	<li>Extra calculate for additional programs as per above itinerary.</li>\r\n	<li>Travel and rescue insurance.</li>\r\n	<li>Local donation &amp; Tips for guides and porters.</li>\r\n	<li>Personal expenses (Pot of tea, bar bills, battery recharge, extra porters, bottle or boiled water, shower etc)</li>\r\n</ul>\r\n', 146, 0, 0),
(3, 4, 'Chitwan Jungle Safari - Elephant Ride', 'img718_2016_07_21_10_24_47.jpg', '<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don&#39;t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&#39;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>\r\n', NULL, 'Chitwan-Jungle-Safari---Elephant-Ride', NULL, 0, NULL, NULL, NULL, NULL, NULL, 146, 0, 0),
(4, 12, 'Helicoptor/Aeroplane Mountain Sighting', 'img292_2016_07_21_10_31_31.jpg', '<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don&#39;t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&#39;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>\r\n', NULL, 'Helicoptor-Aeroplane-Mountain-Sighting', NULL, 0, NULL, NULL, NULL, NULL, NULL, 11, 0, 0),
(5, 2, 'Helambu Trek', 'img415_2016_07_21_10_43_31.jpg', '<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don&#39;t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&#39;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>\r\n', NULL, 'Helambu-Trek', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0),
(6, 12, 'Paragliding Pokhara', 'img151_2016_07_21_11_29_19.jpg', '<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don&#39;t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&#39;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>\r\n', NULL, 'Paragliding-Pokhara', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0),
(7, 1, 'Canoeing Kaligandaki', 'img573_2016_07_21_11_36_38.jpg', '<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don&#39;t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&#39;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>\r\n', NULL, 'Canoeing-Kaligandaki', 'Easy', 3, '', '', NULL, '', '', NULL, 0, 0),
(8, 13, 'Bunzy Jumping - Over Bhote Koshi', 'img269_2016_07_21_11_40_00.jpg', '<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don&#39;t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&#39;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>\r\n', NULL, 'Bunzy-Jumping---Over-Bhote-Koshi', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0),
(9, 1, 'Rafting on Bhotekoshi', 'img323_2016_08_29_09_38_38.jpg', '<p>rafting</p>\r\n', NULL, 'Rafting-on-Bhotekoshi', 'Easy', 3, '', '', NULL, '', '<p>incudes all costs</p>\r\n', NULL, 1, 0),
(10, 3, 'Manaslu Climbing', 'img79_2016_08_29_10_04_52.jpg', '<p>asda ssdasd asdasd</p>\r\n', NULL, 'Manaslu-Climbing', 'Moderate', 6, '', '', NULL, 'September', '<p>All cost included</p>\r\n', NULL, 0, 0),
(11, 14, 'test', 'img246_2017_04_30_13_30_15.jpg', '<p>asda sdasda sdasdas dasd asdas</p>\r\n', NULL, 'test', 'Easy', 0, 'a', 'b', NULL, 'September', '<p>aasd asdasd asdasd as asdas asdas asdas asdas asdasd asda asdasd</p>\r\n', 146, 1, 0),
(12, 1, 'asdasdas', 'img601_2017_04_30_13_05_24.jpg', '<p>asd asdas asdasdas</p>\r\n', NULL, 'asdasdas', 'Easy', 0, 'asdas', 'dasdasd', NULL, 'asdas asdasdasd', '<p>asd asd asdasdasd</p>\r\n', 2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `package_category`
--

DROP TABLE IF EXISTS `package_category`;
CREATE TABLE IF NOT EXISTS `package_category` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `package_category`
--

INSERT INTO `package_category` (`id`, `title`, `slug`) VALUES
(1, 'Rafting', 'rafting'),
(2, 'Trekking/Hiking', 'trekking-hiking'),
(3, 'Peak Climbing', 'peak-climbing'),
(4, 'Jungle Safari', 'jungle-safari'),
(12, 'Paragliding/Helicoptor', 'paragliding-helicoptor'),
(13, 'Bunzy Jumping', 'bunzy-jumping'),
(14, 'Test', 'Test');

-- --------------------------------------------------------

--
-- Table structure for table `package_img`
--

DROP TABLE IF EXISTS `package_img`;
CREATE TABLE IF NOT EXISTS `package_img` (
  `id` int(11) NOT NULL,
  `package_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `caption` text
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `package_img`
--

INSERT INTO `package_img` (`id`, `package_id`, `image`, `caption`) VALUES
(3, 12, 'img601_2017_04_30_13_05_24.jpg', 'a sdasdas sdasda'),
(4, 12, 'img23_2017_04_30_13_07_15.jpg', 'asda sdas adsd asd as asdas'),
(5, 11, 'img246_2017_04_30_13_30_15.jpg', 'asd asdasd asdasd asdas');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL,
  `cat_id` int(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `slug` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `cat_id`, `title`, `description`, `slug`) VALUES
(2, 2, 'Trekking and Hiking', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', 'trekking-and-hiking'),
(3, 3, 'Tibet Tour', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n<p>\r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'tibet-tour'),
(4, 4, 'Introduction of Nepal', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n<p>\r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'introduction-of-nepal'),
(5, 1, 'About Us', '<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot; (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, &quot;Lorem ipsum dolor sit amet..&quot;, comes from a line in section 1.10.32.</p>\r\n\r\n<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from &quot;de Finibus Bonorum et Malorum&quot; by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>\r\n\r\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot; (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, &quot;Lorem ipsum dolor sit amet..&quot;, comes from a line in section 1.10.32.</p>\r\n\r\n<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from &quot;de Finibus Bonorum et Malorum&quot; by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>\r\n', 'about-us'),
(6, 1, 'Contact Us', '<p>GoldenCloud Adventure&rdquo; is dedicated to helping trekkers succeed by producing best-in-industry guides and information.We welcome feedback, but please note that we are not currently accepting new contributors or unsolicited guest posts at this time.</p>\r\n\r\n<p><strong>Mailing something to Golden Cloud Adventure? Send it here:</strong></p>\r\n\r\n<p>Narshing Chowk, Thamel</p>\r\n\r\n<p>Kathmandu 44600, Nepal</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', 'Contact-Us'),
(7, 2, 'Rafting in Nepal', '<p>test test</p>\r\n', 'Rafting');

-- --------------------------------------------------------

--
-- Table structure for table `page_category`
--

DROP TABLE IF EXISTS `page_category`;
CREATE TABLE IF NOT EXISTS `page_category` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `page_category`
--

INSERT INTO `page_category` (`id`, `title`, `slug`) VALUES
(1, 'Main Pages', 'main'),
(2, 'Travel Services In Nepal', 'travel-services-in-nepal'),
(3, 'Travel Services Out Of Nepal', 'travel-services-out-of-nepal'),
(4, 'Traveller''s Guide', 'travellers-guide');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

DROP TABLE IF EXISTS `sliders`;
CREATE TABLE IF NOT EXISTS `sliders` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `caption` text NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `title`, `caption`, `image`) VALUES
(1, '<p>Feel the <strong>chill of</strong> Himalayas asda sasdas asd</p><br />\r\n<br />\r\n<p>&nbsp;</p><br />\r\n', 'Well trained<br /><br />\r\nEnglish speaking guide to assist you.asd asda d', '917541_857513.jpg'),
(2, '<p>Feel the <strong>chill of</strong> Himalayas</p><br />\r\n', 'Well trained<br />\r\nEnglish speaking guide to assist you.', '673828_824005.jpg'),
(4, '<p>Feel the chill of Himalayas</p><br />\r\n', 'Well trained<br />\r\nEnglish speaking guide to assist you.', '175170_282867.jpg'),
(5, '<p>Feel the <strong>chill of</strong> Himalayas</p><br />\r\n', 'Well trained<br />\r\nEnglish speaking guide to assist you.', '506164_642425.jpg'),
(6, '<p>&nbsp;asdas asdasd asdasd</p><br />\r\n', 'asd asdasdas asd asdas', '179351_222961.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL,
  `video_id` int(11) DEFAULT NULL,
  `page_id` int(11) DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `tour_id` int(11) DEFAULT NULL,
  `blog_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `video_id`, `page_id`, `package_id`, `tour_id`, `blog_id`) VALUES
(12, 6, NULL, 4, NULL, NULL),
(13, 7, NULL, 4, NULL, NULL),
(14, 8, NULL, 4, NULL, NULL),
(15, 9, NULL, 4, NULL, NULL),
(16, 10, NULL, 1, NULL, NULL),
(17, 11, NULL, 1, NULL, NULL),
(18, 12, NULL, 1, NULL, NULL),
(19, 13, NULL, 1, NULL, NULL),
(20, 14, NULL, 2, NULL, NULL),
(21, 15, NULL, 2, NULL, NULL),
(22, 16, NULL, 2, NULL, NULL),
(23, 17, NULL, 2, NULL, NULL),
(24, 18, NULL, 12, NULL, NULL),
(25, 19, NULL, 12, NULL, NULL),
(26, 20, NULL, 12, NULL, NULL),
(27, 21, NULL, 12, NULL, NULL),
(28, 22, NULL, 13, NULL, NULL),
(29, 23, NULL, 13, NULL, NULL),
(30, 24, NULL, 13, NULL, NULL),
(31, 25, NULL, 13, NULL, NULL),
(32, 26, NULL, 13, NULL, NULL),
(41, 5, NULL, 1, NULL, NULL),
(43, NULL, 2, 2, NULL, NULL),
(44, NULL, 2, NULL, 7, NULL),
(48, NULL, NULL, 1, NULL, 1),
(49, NULL, NULL, 2, NULL, 1),
(50, NULL, NULL, 12, NULL, 1),
(51, NULL, NULL, 1, NULL, 2),
(52, NULL, NULL, 2, NULL, 2),
(53, NULL, NULL, 4, NULL, 2),
(54, NULL, NULL, 1, NULL, 3),
(55, NULL, NULL, 2, NULL, 4),
(56, NULL, NULL, 2, NULL, 5),
(57, NULL, NULL, 3, NULL, 5),
(58, NULL, NULL, 4, NULL, 5),
(60, NULL, 7, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_countries`
--

DROP TABLE IF EXISTS `tbl_countries`;
CREATE TABLE IF NOT EXISTS `tbl_countries` (
  `id` int(11) NOT NULL DEFAULT '0',
  `countryName` varchar(100) NOT NULL DEFAULT '',
  `twoLetterISOCode` varchar(2) NOT NULL DEFAULT '',
  `threeLetterISOCode` varchar(3) NOT NULL DEFAULT '',
  `numericISOCode` varchar(3) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_countries`
--

INSERT INTO `tbl_countries` (`id`, `countryName`, `twoLetterISOCode`, `threeLetterISOCode`, `numericISOCode`) VALUES
(1, 'Afghanistan', 'AF', 'AFG', '004'),
(2, 'Albania', 'AL', 'ALB', '008'),
(3, 'Algeria', 'DZ', 'DZA', '012'),
(4, 'American Samoa', 'AS', 'ASM', '016'),
(5, 'Andorra', 'AD', 'AND', '020'),
(6, 'Angola', 'AO', 'AGO', '024'),
(7, 'Anguilla', 'AI', 'AIA', '660'),
(8, 'Antarctica', 'AQ', 'ATA', '010'),
(9, 'Antigua and Barbuda', 'AG', 'ATG', '028'),
(10, 'Argentina', 'AR', 'ARG', '032'),
(11, 'Armenia', 'AM', 'ARM', '051'),
(12, 'Aruba', 'AW', 'ABW', '533'),
(13, 'Australia', 'AU', 'AUS', '036'),
(14, 'Austria', 'AT', 'AUT', '040'),
(15, 'Azerbaijan', 'AZ', 'AZE', '031'),
(16, 'Bahamas', 'BS', 'BHS', '044'),
(17, 'Bahrain', 'BH', 'BHR', '048'),
(18, 'Bangladesh', 'BD', 'BGD', '050'),
(19, 'Barbados', 'BB', 'BRB', '052'),
(20, 'Belarus', 'BY', 'BLR', '112'),
(21, 'Belgium', 'BE', 'BEL', '056'),
(22, 'Belize', 'BZ', 'BLZ', '084'),
(23, 'Benin', 'BJ', 'BEN', '204'),
(24, 'Bermuda', 'BM', 'BMU', '060'),
(25, 'Bhutan', 'BT', 'BTN', '064'),
(26, 'Bolivia', 'BO', 'BOL', '068'),
(27, 'Bosnia and Herzegowina', 'BA', 'BIH', '070'),
(28, 'Botswana', 'BW', 'BWA', '072'),
(29, 'Bouvet Island', 'BV', 'BVT', '074'),
(30, 'Brazil', 'BR', 'BRA', '076'),
(31, 'British Indian Ocean Territory', 'IO', 'IOT', '086'),
(32, 'Brunei Darussalam', 'BN', 'BRN', '096'),
(33, 'Bulgaria', 'BG', 'BGR', '100'),
(34, 'Burkina Faso', 'BF', 'BFA', '854'),
(35, 'Burundi', 'BI', 'BDI', '108'),
(36, 'Cambodia', 'KH', 'KHM', '116'),
(37, 'Canada', 'CA', 'CAN', '124'),
(38, 'Cape Verde', 'CV', 'CPV', '13'),
(39, 'Cayman Islands', 'KY', 'CYM', '136'),
(40, 'Central African Republic', 'CF', 'CAF', '140'),
(41, 'Chad', 'TD', 'TCD', '148'),
(42, 'Chile', 'CL', 'CHL', '152'),
(43, 'China', 'CN', 'CHN', '156'),
(44, 'Christmas Island', 'CX', 'CXR', '162'),
(45, 'Cocos (Keeling) Islands', 'CC', 'CCK', '166'),
(46, 'Colombia', 'CO', 'COL', '170'),
(47, 'Comoros', 'KM', 'COM', '174'),
(48, 'Congo', 'CG', 'COG', '178'),
(49, 'Congo', ' t', 'CD', 'COD'),
(50, 'Cook Islands', 'CK', 'COK', '184'),
(51, 'Costa Rica', 'CR', 'CRI', '188'),
(52, 'Cote d''Ivoire', 'CI', 'CIV', '384'),
(53, 'Croatia (local name: Hrvatska)', 'HR', 'HRV', '191'),
(54, 'Cuba', 'CU', 'CUB', '192'),
(55, 'Cyprus', 'CY', 'CYP', '196'),
(56, 'Czech Republic', 'CZ', 'CZE', '203'),
(57, 'Denmark', 'DK', 'DNK', '208'),
(58, 'Djibouti', 'DJ', 'DJI', '262'),
(59, 'Dominica', 'DM', 'DMA', '212'),
(60, 'Dominican Republic', 'DO', 'DOM', '214'),
(61, 'East Timor', 'TP', 'TMP', '626'),
(62, 'Ecuador', 'EC', 'ECU', '218'),
(63, 'Egypt', 'EG', 'EGY', '818'),
(64, 'El Salvador', 'SV', 'SLV', '222'),
(65, 'Falkland Islands (Malvinas)', 'FK', 'FLK', '238'),
(66, 'Faroe Islands', 'FO', 'FRO', '234'),
(67, 'Fiji', 'FJ', 'FJI', '242'),
(68, 'Finland', 'FI', 'FIN', '246'),
(69, 'France', 'FR', 'FRA', '250'),
(70, 'France', ' M', 'FX', 'FXX'),
(71, 'French Guiana', 'GF', 'GUF', '254'),
(72, 'French Polynesia', 'PF', 'PYF', '258'),
(73, 'French Southern Territories', 'TF', 'ATF', '260'),
(74, 'Gabon', 'GA', 'GAB', '266'),
(75, 'Gambia', 'GM', 'GMB', '270'),
(76, 'Georgia', 'GE', 'GEO', '268'),
(77, 'Germany', 'DE', 'DEU', '276'),
(78, 'Ghana', 'GH', 'GHA', '288'),
(79, 'Gibraltar', 'GI', 'GIB', '292'),
(80, 'Greece', 'GR', 'GRC', '300'),
(81, 'Greenland', 'GL', 'GRL', '304'),
(82, 'Grenada', 'GD', 'GRD', '308'),
(83, 'Guadeloupe', 'GP', 'GLP', '312'),
(84, 'Guam', 'GU', 'GUM', '316'),
(85, 'Guatemala', 'GT', 'GTM', '320'),
(86, 'Guinea', 'GN', 'GIN', '324'),
(87, 'Guinea-Bissau', 'GW', 'GNB', '624'),
(88, 'Guyana', 'GY', 'GUY', '328'),
(89, 'Haiti', 'HT', 'HTI', '332'),
(90, 'Heard and Mc Donald Islands', 'HM', 'HMD', '334'),
(91, 'Holy see (Vatican City State)', 'VA', 'VAT', '336'),
(92, 'Honduras', 'HN', 'HND', '340'),
(93, 'Hong Kong', 'HK', 'HKG', '344'),
(94, 'Hungary', 'HU', 'HUN', '348'),
(95, 'Iceland', 'IS', 'ISL', '352'),
(96, 'India', 'IN', 'IND', '356'),
(97, 'Indonesia', 'ID', 'IDN', '360'),
(98, 'Iran (Islamic Republic of)', 'IR', 'IRN', '364'),
(99, 'Iraq', 'IQ', 'IRQ', '368'),
(100, 'Ireland', 'IE', 'IRL', '372'),
(101, 'Israel', 'IL', 'ISR', '376'),
(102, 'Italy', 'IT', 'ITA', '380'),
(103, 'Jamaica', 'JM', 'JAM', '388'),
(104, 'Japan', 'JP', 'JPN', '392'),
(105, 'Jordan', 'JO', 'JOR', '400'),
(106, 'Kazakhstan', 'KZ', 'KAZ', '398'),
(107, 'Kenya', 'KE', 'KEN', '404'),
(108, 'Kiribati', 'KI', 'KIR', '296'),
(109, 'Korea', ' D', 'KP', 'PRK'),
(110, 'Korea', ' R', 'KR', 'KOR'),
(111, 'Kuwait', 'KW', 'KWT', '414'),
(112, 'Kyrgyzstan', 'KG', 'KGZ', '417'),
(114, 'Latvia', 'LV', 'LVA', '428'),
(115, 'Lebanon', 'LB', 'LBN', '422'),
(116, 'Lesotho', 'LS', 'LSO', '426'),
(117, 'Liberia', 'LR', 'LBR', '430'),
(118, 'Libyan Arab Jamahiriya', 'LY', 'LBY', '434'),
(119, 'Liechtenstein', 'LI', 'LIE', '438'),
(120, 'Lithuania', 'LT', 'LTU', '440'),
(121, 'Luxembourg', 'LU', 'LUX', '442'),
(122, 'Macau', 'MO', 'MAC', '446'),
(123, 'Macedonia', ' t', 'MK', 'MKD'),
(124, 'Madagascar', 'MG', 'MDG', '450'),
(125, 'Malawi', 'MW', 'MWI', '454'),
(126, 'Malaysia', 'MY', 'MYS', '458'),
(127, 'Maldives', 'MV', 'MDV', '462'),
(128, 'Mali', 'ML', 'MLI', '466'),
(129, 'Malta', 'MT', 'MLT', '470'),
(130, 'Marshall Islands', 'MH', 'MHL', '584'),
(131, 'Martinique', 'MQ', 'MTQ', '474'),
(132, 'Mauritania', 'MR', 'MRT', '478'),
(133, 'Mauritius', 'MU', 'MUS', '480'),
(134, 'Mayotte', 'YT', 'MYT', '175'),
(135, 'Mexico', 'MX', 'MEX', '484'),
(136, 'Micronesia', ' F', 'FM', 'FSM'),
(137, 'Moldova', ' R', 'MD', 'MDA'),
(138, 'Monaco', 'MC', 'MCO', '492'),
(139, 'Mongolia', 'MN', 'MNG', '496'),
(140, 'Montserrat', 'MS', 'MSR', '500'),
(141, 'Morocco', 'MA', 'MAR', '504'),
(142, 'Mozambique', 'MZ', 'MOZ', '508'),
(143, 'Myanmar', 'MM', 'MMR', '104'),
(144, 'Namibia', 'NA', 'NAM', '516'),
(145, 'Nauru', 'NR', 'NRU', '520'),
(146, 'Nepal', 'NP', 'NPL', '524'),
(147, 'Netherlands', 'NL', 'NLD', '528'),
(148, 'Netherlands Antilles', 'AN', 'ANT', '530'),
(149, 'New Caledonia', 'NC', 'NCL', '540'),
(150, 'New Zealand', 'NZ', 'NZL', '554'),
(151, 'Nicaragua', 'NI', 'NIC', '558'),
(152, 'Niger', 'NE', 'NER', '562'),
(153, 'Nigeria', 'NG', 'NGA', '566'),
(154, 'Niue', 'NU', 'NIU', '570'),
(155, 'Norfolk Island', 'NF', 'NFK', '574'),
(156, 'Northern Mariana Islands', 'MP', 'MNP', '580'),
(157, 'Norway', 'NO', 'NOR', '578'),
(158, 'Oman', 'OM', 'OMN', '512'),
(159, 'Pakistan', 'PK', 'PAK', '586'),
(160, 'Palau', 'PW', 'PLW', '585'),
(161, 'Palestinian Territory', ' o', 'PS', 'PSE'),
(162, 'Panama', 'PA', 'PAN', '591'),
(163, 'Papua New Guinea', 'PG', 'PNG', '598'),
(164, 'Paraguay', 'PY', 'PRY', '600'),
(165, 'Peru', 'PE', 'PER', '604'),
(166, 'Philippines', 'PH', 'PHL', '608'),
(167, 'Pitcairn', 'PN', 'PCN', '612'),
(168, 'Poland', 'PL', 'POL', '616'),
(169, 'Portugal', 'PT', 'PRT', '620'),
(170, 'Puerto Rico', 'PR', 'PRI', '630'),
(171, 'Qatar', 'QA', 'QAT', '634'),
(172, 'Reunion', 'RE', 'REU', '638'),
(173, 'Romania', 'RO', 'ROM', '642'),
(174, 'Russian Federation', 'RU', 'RUS', '643'),
(175, 'Rwanda', 'RW', 'RWA', '646'),
(176, 'Saint Kitts and Nevis', 'KN', 'KNA', '659'),
(177, 'Saint Lucia', 'LC', 'LCA', '662'),
(179, 'Samoa', 'WS', 'WSM', '882'),
(180, 'San Marino', 'SM', 'SMR', '674'),
(181, 'Sao Tome and Principe', 'ST', 'STP', '678'),
(182, 'Saudi Arabia', 'SA', 'SAU', '682'),
(183, 'Senegal', 'SN', 'SEN', '686'),
(184, 'Seychelles', 'SC', 'SYC', '690'),
(185, 'Sierra Leone', 'SL', 'SLE', '694'),
(186, 'Singapore', 'SG', 'SGP', '702'),
(187, 'Slovakia (Slovak Republic)', 'SK', 'SVK', '703'),
(188, 'Slovenia', 'SI', 'SVN', '705'),
(189, 'Solomon Islands', 'SB', 'SLB', '090'),
(190, 'Somalia', 'SO', 'SOM', '706'),
(191, 'South Africa', 'ZA', 'ZAF', '710'),
(193, 'Spain', 'ES', 'ESP', '724'),
(194, 'Sri Lanka', 'LK', 'LKA', '144'),
(195, 'St. Helena', 'SH', 'SHN', '654'),
(196, 'St. Pierre and Miquelon', 'PM', 'SPM', '666'),
(197, 'Sudan', 'SD', 'SDN', '736'),
(198, 'Suriname', 'SR', 'SUR', '740'),
(199, 'Svalbard and Jan Mayen Islands', 'SJ', 'SJM', '744'),
(200, 'Swaziland', 'SZ', 'SWZ', '748'),
(201, 'Sweden', 'SE', 'SWE', '752'),
(202, 'Switzerland', 'CH', 'CHE', '756'),
(203, 'Syrian Arab Republic', 'SY', 'SYR', '760'),
(204, 'Taiwan', ' R', 'TW', 'TWN'),
(205, 'Tajikistan', 'TJ', 'TJK', '762'),
(206, 'Tanzania', ' U', 'TZ', 'TZA'),
(207, 'Thailand', 'TH', 'THA', '764'),
(208, 'Togo', 'TG', 'TGO', '768'),
(209, 'Tokelau', 'TK', 'TKL', '772'),
(210, 'Tonga', 'TO', 'TON', '776'),
(211, 'Trinidad and Tobago', 'TT', 'TTO', '780'),
(212, 'Tunisia', 'TN', 'TUN', '788'),
(213, 'Turkey', 'TR', 'TUR', '792'),
(214, 'Turkmenistan', 'TM', 'TKM', '795'),
(215, 'Turks and Caicos Islands', 'TC', 'TCA', '796'),
(216, 'Tuvalu', 'TV', 'TUV', '798'),
(217, 'Uganda', 'UG', 'UGA', '800'),
(218, 'Ukraine', 'UA', 'UKR', '804'),
(219, 'United Arab Emirates', 'AE', 'ARE', '784'),
(220, 'United Kingdom', 'GB', 'GBR', '826'),
(221, 'United States', 'US', 'USA', '840'),
(223, 'Uruguay', 'UY', 'URY', '858'),
(224, 'Uzbekistan', 'UZ', 'UZB', '860'),
(225, 'Vanuatu', 'VU', 'VUT', '548'),
(226, 'Venezuela', 'VE', 'VEN', '862'),
(227, 'Viet Nam', 'VN', 'VNM', '704'),
(228, 'Virgin Islands (British)', 'VG', 'VGB', '092'),
(229, 'Virgin Islands (U.S.)', 'VI', 'VIR', '850'),
(230, 'Wallis and Futuna Islands', 'WF', 'WLF', '876'),
(231, 'Western Sahara', 'EH', 'ESH', '732'),
(232, 'Yemen', 'YE', 'YEM', '887'),
(233, 'Yugoslavia', 'YU', 'YUG', '891'),
(234, 'Zambia', 'ZM', 'ZMB', '894'),
(235, 'Zimbabwe', 'ZW', 'ZWE', '716');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
CREATE TABLE IF NOT EXISTS `teams` (
  `title` varchar(100) NOT NULL,
  `id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `is_testimonial` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`title`, `id`, `image`, `designation`, `description`, `is_testimonial`) VALUES
('Message From Md', 2, '25024_791900.jpg', '', '<p><strong>Warm greetings from Golden Cloud Adventure family.</strong><br />\r\n<br />\r\nOur team of experts will be glad to welcome our valued customers. With our rich knowledge and hands on experience blend with social network palladium in the field of Trekking, Rafting, Expedition or Mountaineering, Safari etc. Our dedicated staff will strive hard possible to achieve your desired expectation through total customers satisfaction. Myself as I am working in mountaineering and Nepal tourism since 16 years I proudly can tell you that we will make your visit in Nepal memorable. Starting in tourism as porter, upgrading by Trekking guide and tour guide after that working in another agency as tour operate, I decided to start this agency. Therefore I understand all the needs and services for the tourist who visit Nepal. ?I was also working as coordinator of Welfare and Crisis Management in Trekking Agencies Association of Nepal (TAAN) after being elected from more than 1500 trekking agencies (2013-2015) I had good change to betterment my knowledge in this field. Recently I am also elected in NGOs Federation of Nepal, Kathmandu (NFN) on Feb.2016 to work together in social services or betterment of NGOs in Nepal. All the staffs that works with us are highly experience too. ?After all the experiences we are highly motivated in betterment of Nepal Tourism. Our slogan where the joy is the journey, where the destination is within yourself, is ready to go for extra miles.<br />\r\n<br />\r\nOur team members can lead you to the places which you have never seen or read in any websites or books. At every destination, our wide range of itineraries would take you to ancient cities, mountain trails with varied sceneries making you bolt from the blue.<br />\r\n<br />\r\nGo out of your comfort zone. Come let us make your dream holiday come true. Our outshining support teams, world class travel and tour services will surely prove that Nepal, is belong to one thousand place to visit as quoted in the travel and living channel.<br />\r\n<br />\r\nAs instrumental in providing the basic needs of those destitute members of our society in city itself and various districts around the country, we set aside certain percentage of our earnings for the development of education, health care and clothing facilities. This effort is concerted by group of friends and travel enthusiast from all over the world.<br />\r\n<br />\r\n<strong>With best regards,<br />\r\nBikash Shrestha<br />\r\nGolden Cloud Adventure Pvt. Ltd.</strong></p>\r\n', 1),
('asdas dasdas ', 3, '365783_215911.jpg', '', '<p>asda sdasdasda sdasd asda sd asdasdas das</p>\r\n', 1),
('Chatak Ali', 4, '351684_147857.jpg', 'CEO', '<p>asdda dad adadad a da da dad</p>\r\n', 0),
('Kumar', 5, '852752_92407.jpg', 'CEO', '<p>asdas asdas adasd</p>\r\n', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tours`
--

DROP TABLE IF EXISTS `tours`;
CREATE TABLE IF NOT EXISTS `tours` (
  `id` int(11) NOT NULL,
  `cat_id` int(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `added_on` date DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `grade` varchar(255) DEFAULT NULL,
  `start_point` varchar(255) DEFAULT NULL,
  `end_point` varchar(255) DEFAULT NULL,
  `route_map` varchar(255) DEFAULT NULL,
  `best_time` varchar(255) DEFAULT NULL,
  `cost_detail` text,
  `country_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tours`
--

INSERT INTO `tours` (`id`, `cat_id`, `title`, `image`, `description`, `added_on`, `slug`, `grade`, `start_point`, `end_point`, `route_map`, `best_time`, `cost_detail`, `country_id`) VALUES
(2, 6, 'test11111', '', '<p>t is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n', NULL, 'test11111-20160721120807', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 3, 'test444444', '', '', NULL, 'test444444-20160721120757', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 7, 'Front end test', 'img20_2016_08_22_05_02_48.jpg', '<p>test</p>\r\n', NULL, 'Front-end-test', 'Easy', '', '', NULL, '', '<p>test</p>\r\n', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tour_category`
--

DROP TABLE IF EXISTS `tour_category`;
CREATE TABLE IF NOT EXISTS `tour_category` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tour_category`
--

INSERT INTO `tour_category` (`id`, `title`, `slug`) VALUES
(3, 'tset', 'tset'),
(6, 'asdsadsad', 'asdsadsad'),
(7, 'test2222222', 'test2222222');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
CREATE TABLE IF NOT EXISTS `videos` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `title`, `youtube`) VALUES
(5, NULL, 'https://www.youtube.com/watch?v=lk8BrdhxaVM'),
(6, NULL, 'https://www.youtube.com/watch?v=s4O6vU3RYAE'),
(7, NULL, 'https://www.youtube.com/watch?v=OtXKa-CNwrs'),
(8, NULL, 'https://www.youtube.com/watch?v=xhQnCde3ROw'),
(9, NULL, 'https://www.youtube.com/watch?v=1uAvWg5KRvs'),
(10, NULL, 'https://www.youtube.com/watch?v=YFvgCj3NtI4'),
(11, NULL, 'https://www.youtube.com/watch?v=GbmDVFgsYOY'),
(12, NULL, 'https://www.youtube.com/watch?v=eHFs2aSlfA0'),
(13, NULL, 'https://www.youtube.com/watch?v=YMthjGFhBBo'),
(14, NULL, 'https://www.youtube.com/watch?v=vPhMaL2NfCo'),
(15, NULL, 'https://www.youtube.com/watch?v=aRwW1tmj1Hc'),
(16, NULL, 'https://www.youtube.com/watch?v=c6STl40y50k'),
(17, NULL, 'https://www.youtube.com/watch?v=vntXFxsDpfQ'),
(18, NULL, 'https://www.youtube.com/watch?v=NSUEt2T2Bq4'),
(19, NULL, 'https://www.youtube.com/watch?v=L84C8jrD5dk'),
(20, NULL, 'https://www.youtube.com/watch?v=i_Qt_UFA-qU'),
(21, NULL, 'https://www.youtube.com/watch?v=c64zh0Bx_8M'),
(22, NULL, 'https://www.youtube.com/watch?v=yFOZHa2pn1g'),
(23, NULL, 'https://www.youtube.com/watch?v=VZ2CPdIPa30'),
(24, NULL, 'https://www.youtube.com/watch?v=-ougJbk-yhI'),
(25, NULL, 'https://www.youtube.com/watch?v=ZMepnXkqgqk'),
(26, NULL, 'https://www.youtube.com/watch?v=PZ-6qvJ8y3w');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiry`
--
ALTER TABLE `enquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `iteniery`
--
ALTER TABLE `iteniery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package_category`
--
ALTER TABLE `package_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package_img`
--
ALTER TABLE `package_img`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_category`
--
ALTER TABLE `page_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_countries`
--
ALTER TABLE `tbl_countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tours`
--
ALTER TABLE `tours`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tour_category`
--
ALTER TABLE `tour_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `enquiry`
--
ALTER TABLE `enquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `iteniery`
--
ALTER TABLE `iteniery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=276;
--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `package_category`
--
ALTER TABLE `package_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `package_img`
--
ALTER TABLE `package_img`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `page_category`
--
ALTER TABLE `page_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tours`
--
ALTER TABLE `tours`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tour_category`
--
ALTER TABLE `tour_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
